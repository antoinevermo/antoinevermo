package com.example.Practica4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Practica4ApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class Player implements PlayerService {

    @Override
    public List<String> getPlayers() {
        return List.of(
                "Jayson Tatum #0",
                "Jaylen Brown #7",
                "Kemba Walker #8"
        );
    }
}

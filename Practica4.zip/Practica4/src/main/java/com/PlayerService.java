package com;

import java.util.List;

public interface PlayerService {

    List<String> getPlayers();
}

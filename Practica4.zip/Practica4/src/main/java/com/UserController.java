package com;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class UserController {

    @Autowired
    public UserService userservice;

    @Autowired
    private PlayerService players;

    @GetMapping("/status")
    public ResponseEntity<String> status() {
        return new ResponseEntity<>("{\"result\" : \"OK\"}", HttpStatus.OK);
    }


    @PostMapping(
            path = "/login", consumes = "application/json", produces = "application/json")

    public ResponseEntity<String> login(
            @RequestBody User user,
            BindingResult bR) {

        if (bR.hasErrors()) {
            return new ResponseEntity<>("{\"result\" : \"KO\"}", HttpStatus.BAD_REQUEST);
        }
        for (User u: userservice.getUsers() ) {
            if ((user.getEmail().equals(u.getEmail())) &&
                    (user.getPassword().equals(u.getPassword()))) {
                return new ResponseEntity<>("{\"result\" : \"OK\"}", HttpStatus.OK);
            }
        }

        return new ResponseEntity<>("{\"result\" : \"KO\"}", HttpStatus.UNAUTHORIZED);
    }

    @GetMapping("/Player")
    public List<String> getPlayers() { return players.getPlayers(); }
}

package com;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {
    List<User> Users = new ArrayList<>();
    User user1 =new User("kemba.walker@gmail.com","KW8");
    User user2 =new User("jaylen.brown@gmail.com","JB7");
    User user3 =new User("jayson.tatum@gmail.com","JT0");
    User user4 =new User("marcus.smart@gmail.com","MS36");
    User user5 =new User("tristan.thompson@gmail.com","TT13");


    public UserService(){
        Users.add(user1);
        Users.add(user2);
        Users.add(user3);
        Users.add(user4);
        Users.add(user5);}

    public List<User> getUsers() {
        return Users;

    }
}
